/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Luthfi Alfarisi
 */
public class utama {
    public static void main(String[] args) {
        frmUtama ut = new frmUtama();
        ut.setVisible(true);
        ut.setResizable(false);
        ut.setTitle("Aplikasi Pengolahan Data Mahasiswa");
        ut.setLocationRelativeTo(null);
    }
}
