package be.vergauwen.simon.kotlinvanillamvp

import android.app.Application

class MVPApplication : Application()