package be.vergauwen.simon.cleanmvp;

import android.app.Application;

public class MVPApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
