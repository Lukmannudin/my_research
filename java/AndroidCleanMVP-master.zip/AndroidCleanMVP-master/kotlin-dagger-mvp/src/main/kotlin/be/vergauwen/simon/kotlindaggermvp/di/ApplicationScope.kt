package be.vergauwen.simon.kotlindaggermvp.di

import javax.inject.Scope

@Scope
@kotlin.annotation.Retention
annotation class ApplicationScope