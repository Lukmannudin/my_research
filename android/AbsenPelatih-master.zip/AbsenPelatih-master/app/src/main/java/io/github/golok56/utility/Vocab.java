package io.github.golok56.utility;

public final class Vocab {
    public static final String PASSWORD = "PASSWORD";
    public static final String DEFAULT_PASSWORD = "yetececiteureup";
    public static final String PREF_NAME = "pass_preference";
    public static final String SCHOOL_EXTRA = "SCHOOL_EXTRA";
    public static final String NUMBER_PICKER_VALUE_EXTRA = "NUMBER_PICKER_VALUE_EXTRA";
}
